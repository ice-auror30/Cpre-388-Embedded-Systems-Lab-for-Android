package cpre388.iastate.sketchpad;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class SketchPad extends Activity {

        private static final int ROWS = 32;
        private static final int COLS = 32;

	// TAG is used to debug in Android logcat console
		private static final String TAG = "ArduinoAccessory";

		private static final String ACTION_USB_PERMISSION = "com.google.android.DemoKit.action.USB_PERMISSION";

		private UsbManager mUsbManager;
		private PendingIntent mPermissionIntent;
		private boolean mPermissionRequestPending;

		UsbAccessory mAccessory;
        ParcelFileDescriptor mFileDescriptor;
		FileInputStream mInputStream;
		FileOutputStream mOutputStream;

        TableLayout grid;
        private int gridLeft;
        private int gridRight;
        private int gridTop;
        private int gridBottom;
        private int gridWidth;
        private int gridHeight;

        private SeekBar red;
        private SeekBar green;
        private SeekBar blue;
        private int color;
        private ImageView colorPreview;
        private boolean erasing;

        Button[][] buttons = new Button[ROWS][COLS];
        ImageButton eraserButton;

		private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();
				if (ACTION_USB_PERMISSION.equals(action)) {
					synchronized (this) {
						UsbAccessory accessory = (UsbAccessory) intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY);
						if (intent.getBooleanExtra(
								UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
							openAccessory(accessory);
						} else {
							Log.d(TAG, "permission denied for accessory "
									+ accessory);
						}
						mPermissionRequestPending = false;
					}
				} else if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(action)) {
					UsbAccessory accessory = (UsbAccessory) intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY);
					if (accessory != null && accessory.equals(mAccessory)) {
						closeAccessory();
					}
				}
			}
		};


		private void openAccessory(UsbAccessory accessory) {
			mFileDescriptor = mUsbManager.openAccessory(accessory);
			if (mFileDescriptor != null) {
				mAccessory = accessory;
				FileDescriptor fd = mFileDescriptor.getFileDescriptor();
				mInputStream = new FileInputStream(fd);
				mOutputStream = new FileOutputStream(fd);
				Log.d(TAG, "accessory opened");
			} else {
				Log.d(TAG, "accessory open fail");
			}
		}


		private void closeAccessory() {
			try {
				if (mFileDescriptor != null) {
					mFileDescriptor.close();
				}
			} catch (IOException e) {
			} finally {
				mFileDescriptor = null;
				mAccessory = null;
			}
		}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mUsbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        mPermissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
        registerReceiver(mUsbReceiver, filter);

        setContentView(R.layout.activity_sketchpad);
        initControls();
        generateGrid();
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.run, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onResume() {
		super.onResume();

		if (mInputStream != null && mOutputStream != null) {
			return;
		}

		UsbAccessory[] accessories = mUsbManager.getAccessoryList();
		UsbAccessory accessory = (accessories == null ? null : accessories[0]);
		if (accessory != null) {
			if (mUsbManager.hasPermission(accessory)) {
				openAccessory(accessory);
			} else {
				synchronized (mUsbReceiver) {
					if (!mPermissionRequestPending) {
						mUsbManager.requestPermission(accessory,mPermissionIntent);
						mPermissionRequestPending = true;
					}
				}
			}
		} else {
			Log.d(TAG, "mAccessory is null");
		}
	}

	@Override
	public void onPause() {
		super.onPause();
		closeAccessory();
	}

	@Override
	public void onDestroy() {
        unregisterReceiver(mUsbReceiver);
        super.onDestroy();
    }

    public void initControls() {
        red = (SeekBar) findViewById(R.id.red);
        green = (SeekBar) findViewById(R.id.green);
        blue = (SeekBar) findViewById(R.id.blue);

        erasing = false;
        eraserButton = (ImageButton) findViewById(R.id.eraser_button);
        // TODO: Initialize color instance variable and color preview based on initial SeekBar progress.


        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO: Update color instance variable and color preview based on SeekBar progress.
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        };

        red.setOnSeekBarChangeListener(listener);
        green.setOnSeekBarChangeListener(listener);
        blue.setOnSeekBarChangeListener(listener);
    }

    public void generateGrid() {
        grid = (TableLayout) findViewById(R.id.grid);
        // TODO: Add new TableRows and buttons to create a 32x32 grid of buttons.
    }

    private void changeColor(int r, int c) {
        // TODO: Set the background color of the button at (r,c) to the active color or black if erasing.

        // TODO: Get RGB values from progress bars and set the LED at (r,c) to that color or black if erasing.
    }

    public void erase(View v) {
        // TODO: Set the background color of all buttons to black.

        // TODO: Send signal to the Arduino to erase the entire board.
    }

    public void toggleErasing(View v) {
        // TODO: If not erasing, set erasing = true and set eraserButton to be activated and vice versa.
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        gridWidth = grid.getWidth();
        gridHeight = grid.getHeight();
        gridLeft = grid.getLeft();
        gridRight = gridLeft + gridWidth;
        gridTop = grid.getTop() + calculateActivityTop();
        gridBottom = gridTop + grid.getHeight();


        // TODO: Replace "false" with condition to determine whether or not MotionEvent occurs within the bounds of grid.
        // Use e.getX() and e.getY() to complete this task.
        if (false) {
            // If the MotionEvent occurs inside of the grid, then we will handle the event.
            this.handleGridEvent(e);
        } else {
            // If the MotionEvent occurs outside of the grid, then Android will handle the event.
            super.dispatchTouchEvent(e);
        }
        return false;
    };

    private void handleGridEvent(MotionEvent e) {
            // TODO: Use e.getX() and e.getY() to calculate the row and column of a button
            // TODO: where the MotionEvent occurs and call performClick() on that button.
            // Note that e.getX() and e.getY() return the location on the screen and not the coordinates
            // of a button in the grid.
    }

    /*
     * This method calculates the top of the application on the screen
     * to be used as an offset when determining the top of the grid.
     */
    private int calculateActivityTop() {
        int top;
        final TypedArray styledAttributes = getApplicationContext().getTheme().obtainStyledAttributes(
                new int[] { android.R.attr.actionBarSize });
        top = (int) styledAttributes.getDimension(0, 0);
        styledAttributes.recycle();

        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            top += getResources().getDimensionPixelSize(resourceId);
        }
        return top;
    }
}
